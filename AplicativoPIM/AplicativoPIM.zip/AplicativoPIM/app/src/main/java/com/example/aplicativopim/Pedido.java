package com.example.aplicativopim;

import java.math.BigDecimal;
import java.util.Date;

public class Pedido {
    private Long id;
    private BigDecimal valorTotal;
    private String status;
    private Date dataRealizado;
    private Date dataEmTransito;
    private Date dataEntregue;
    private Date dataCancelado;

    public Pedido(Long id, BigDecimal valorTotal, String status,
                  Date dataRealizado, Date dataEmTransito,
                  Date dataEntregue, Date dataCancelado) {
        this.id = id;
        this.valorTotal = valorTotal;
        this.status = status;  // Corrigido: adicionado o status
        this.dataRealizado = dataRealizado;
        this.dataEmTransito = dataEmTransito;
        this.dataEntregue = dataEntregue;
        this.dataCancelado = dataCancelado;
    }

    // Getters permanecem iguais
    public Long getId() {
        return id;
    }

    public BigDecimal getValorTotal() {
        return valorTotal;
    }

    public String getStatus() {
        return status;
    }

    public Date getDataRealizado() {
        return dataRealizado;
    }

    public Date getDataEmTransito() {
        return dataEmTransito;
    }

    public Date getDataEntregue() {
        return dataEntregue;
    }

    public Date getDataCancelado() {
        return dataCancelado;
    }
}